export type RunnerGroup = 'highschool' | 'university'

export interface Runner {
  id: string
  name: string
  group: RunnerGroup
  tossId?: string
  totalKm: number
  totalAmount: number
  pendingAmount: number
}

export interface Submission {
  id: string
  runnerId: string
  runnerName: string
  imageUrl: string | null
  distanceKm: number
  durationSec: number
  paceMinPerKm: number
  submittedAt: string  // ISO 8601
  status: 'pending' | 'approved' | 'rejected'
  approvedAt: string | null
  amount: number
  memo?: string
}

export interface Config {
  totalBudget: number
  spentAmount: number
  adminPassword: string
  ratePerKm: number
  speedMinMinPerKm: number
  speedMaxMinPerKm: number
}

// adminPassword는 서버에서만 사용. 클라이언트 응답에는 포함되지 않음
export type SafeConfig = Omit<Config, 'adminPassword'>

export interface ExtractedRun {
  distanceKm: number
  durationSec: number
  paceMinPerKm: number
}
