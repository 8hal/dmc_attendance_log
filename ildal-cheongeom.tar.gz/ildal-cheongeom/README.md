# 일달천금 (천원길도 1킬로부터)

친구들이 1km 달릴 때마다 스폰서가 1,000원 지급하는 러닝 보상 웹앱.

## 기능

- 러닝 앱 스크린샷 업로드 → AI가 거리/시간 자동 추출
- 스폰서 승인 후 토스 딥링크로 송금
- 리더보드에서 친구들끼리 경쟁

## 기술 스택

- Next.js 16 (App Router) + Tailwind CSS
- Firebase Firestore + Storage
- OpenAI GPT-4o Vision
- Vercel 배포

## 환경 설정

`.env.example`을 복사해서 `.env.local`로 만들고 값을 채워넣으세요.

```bash
cp .env.example .env.local
```

### 필요한 환경변수

- `NEXT_PUBLIC_FIREBASE_*`: Firebase Console → 프로젝트 설정 → 웹 앱
- `FIREBASE_PROJECT_ID`, `FIREBASE_CLIENT_EMAIL`, `FIREBASE_PRIVATE_KEY`: Firebase Console → 서비스 계정
- `OPENAI_API_KEY`: [platform.openai.com](https://platform.openai.com)
- `JWT_SECRET`: `openssl rand -base64 32`

## 초기 설정

### Firestore 초기 데이터 설정

Firebase Console → Firestore → `settings` 컬렉션 → `main` 문서 생성:

```json
{
  "totalBudget": 1000000,
  "spentAmount": 0,
  "adminPassword": "<bcrypt 해시>",
  "ratePerKm": 1000,
  "speedMinMinPerKm": 7,
  "speedMaxMinPerKm": 10
}
```

bcrypt 해시 생성:
```bash
node -e "const bcrypt = require('bcryptjs'); bcrypt.hash('비밀번호', 10).then(console.log)"
```

### Firestore 보안 규칙

`firestore.rules` 내용을 Firebase Console → Firestore → 규칙에 복사 후 게시.

### Firestore 인덱스

`firestore.indexes.json` 내용을 Firebase Console → Firestore → 인덱스에 적용.

### Firebase Storage CORS

```bash
echo '[{"origin": ["*"], "method": ["GET"], "maxAgeSeconds": 3600}]' > cors.json
gsutil cors set cors.json gs://{YOUR_STORAGE_BUCKET}
```

## 로컬 실행

```bash
npm run dev
# http://localhost:3000
```

## 배포 (Vercel)

1. GitHub에 레포 push
2. [vercel.com](https://vercel.com)에서 GitHub 레포 연결
3. 환경변수 설정 (Settings → Environment Variables)
4. 배포 완료

## 화면

| URL | 설명 |
|-----|------|
| `/` | 리더보드 (공개) |
| `/submit` | 달리기 기록 제출 |
| `/records/[runnerId]` | 개인 기록 조회 |
| `/admin` | 관리자 (비밀번호 필요) |
