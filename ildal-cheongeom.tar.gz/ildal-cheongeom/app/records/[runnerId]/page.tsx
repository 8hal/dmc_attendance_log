import { adminDb } from '@/lib/firebase-admin'
import { Runner, Submission } from '@/types'
import { RunnerBadge } from '@/components/RunnerBadge'
import { formatDuration, formatPace } from '@/lib/pace'
import { notFound } from 'next/navigation'
import Link from 'next/link'

const STATUS_LABEL: Record<Submission['status'], string> = {
  pending: '⏳ 대기',
  approved: '✅ 승인',
  rejected: '❌ 거절',
}
const STATUS_COLOR: Record<Submission['status'], string> = {
  pending: 'text-yellow-600 bg-yellow-50',
  approved: 'text-green-600 bg-green-50',
  rejected: 'text-red-500 bg-red-50',
}

export default async function RecordsPage({ params }: { params: Promise<{ runnerId: string }> }) {
  const { runnerId } = await params
  const runnerDoc = await adminDb.doc(`runners/${runnerId}`).get()
  if (!runnerDoc.exists) notFound()
  const runner = { id: runnerDoc.id, ...runnerDoc.data() } as Runner

  const subsSnap = await adminDb.collection('submissions')
    .where('runnerId', '==', runnerId)
    .orderBy('submittedAt', 'desc')
    .get()
  const submissions = subsSnap.docs.map(d => ({ id: d.id, ...d.data() } as Submission))

  return (
    <div className="space-y-4">
      <div className="bg-white rounded-2xl p-4 shadow-sm flex items-center justify-between">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl font-bold text-gray-900">{runner.name}</h1>
            <RunnerBadge group={runner.group} />
          </div>
          <p className="text-sm text-gray-500 mt-1">
            총 {runner.totalKm.toFixed(1)} km · {runner.totalAmount.toLocaleString()}원 획득
          </p>
        </div>
        <Link href="/" className="text-sm text-green-600 font-medium">리더보드</Link>
      </div>

      <div className="space-y-2">
        {submissions.map(sub => (
          <div key={sub.id} className="bg-white rounded-xl p-4 shadow-sm space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-500">
                {new Date(sub.submittedAt).toLocaleDateString('ko-KR')}
              </span>
              <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${STATUS_COLOR[sub.status]}`}>
                {STATUS_LABEL[sub.status]}
              </span>
            </div>
            <div className="flex gap-4 text-sm">
              <span className="font-semibold">{sub.distanceKm.toFixed(2)} km</span>
              <span className="text-gray-500">{formatDuration(sub.durationSec)}</span>
              <span className="text-gray-500">{formatPace(sub.paceMinPerKm)}/km</span>
            </div>
            {sub.status === 'approved' && (
              <p className="text-green-600 font-bold text-sm">+{sub.amount.toLocaleString()}원</p>
            )}
            {sub.status === 'rejected' && sub.memo && (
              <p className="text-red-400 text-xs">사유: {sub.memo}</p>
            )}
            {sub.imageUrl && (
              <a
                href={sub.imageUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="text-xs text-blue-500 underline"
              >
                인증 사진 보기
              </a>
            )}
          </div>
        ))}
        {submissions.length === 0 && (
          <div className="text-center py-8 text-gray-400">아직 제출한 기록이 없습니다</div>
        )}
      </div>
    </div>
  )
}
