'use client'
import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { Runner, ExtractedRun } from '@/types'
import { RunnerSelect } from '@/components/submit/RunnerSelect'
import { ImageUpload } from '@/components/submit/ImageUpload'
import { ExtractResult } from '@/components/submit/ExtractResult'
import { ManualForm } from '@/components/submit/ManualForm'
import { isSpeedValid } from '@/lib/pace'

type Step = 'select' | 'upload' | 'extracting' | 'review' | 'manual' | 'submitting' | 'done'

export default function SubmitPage() {
  const router = useRouter()
  const [runners, setRunners] = useState<Runner[]>([])
  const [runnerId, setRunnerId] = useState('')
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [extracted, setExtracted] = useState<ExtractedRun | null>(null)
  const [step, setStep] = useState<Step>('select')
  const [error, setError] = useState('')
  const [speedWarning, setSpeedWarning] = useState(false)

  useEffect(() => {
    fetch('/api/runners').then(r => r.json()).then(setRunners)
  }, [])

  const handleImage = async (file: File) => {
    setImagePreview(URL.createObjectURL(file))
    setStep('extracting')
    setError('')

    try {
      const formData = new FormData()
      formData.append('image', file)
      const res = await fetch('/api/extract-run', { method: 'POST', body: formData })
      if (!res.ok) throw new Error('서버 오류')
      const data = await res.json()
      setImageUrl(data.imageUrl)

      if (data.extracted) {
        setExtracted(data.extracted)
        setSpeedWarning(!isSpeedValid(data.extracted.paceMinPerKm, 7, 10))
        setStep('review')
      } else {
        setStep('manual')
      }
    } catch {
      setError('이미지 분석에 실패했습니다. 다시 시도하거나 직접 입력해주세요.')
      setStep('manual')
    }
  }

  const handleManual = (data: ExtractedRun) => {
    setExtracted(data)
    setSpeedWarning(!isSpeedValid(data.paceMinPerKm, 7, 10))
    setStep('review')
  }

  const handleSubmit = async () => {
    if (!runnerId || !extracted) return
    const runner = runners.find(r => r.id === runnerId)
    setStep('submitting')
    setError('')

    try {
      const res = await fetch('/api/submissions', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          runnerId,
          runnerName: runner?.name ?? '',
          imageUrl,
          distanceKm: extracted.distanceKm,
          durationSec: extracted.durationSec,
        }),
      })
      if (res.ok) {
        setStep('done')
      } else {
        const body = await res.json()
        setError(body.error ?? '제출에 실패했습니다.')
        setStep('review')
      }
    } catch {
      setError('네트워크 오류가 발생했습니다. 다시 시도해주세요.')
      setStep('review')
    }
  }

  if (step === 'done') {
    return (
      <div className="text-center py-12 space-y-4">
        <p className="text-5xl">🎉</p>
        <p className="text-xl font-bold">제출 완료!</p>
        <p className="text-gray-500 text-sm">스폰서 승인 후 금액이 확정됩니다.</p>
        <button
          onClick={() => router.push('/')}
          className="bg-green-500 text-white px-6 py-2 rounded-full text-sm font-medium"
        >
          리더보드 보기
        </button>
      </div>
    )
  }

  return (
    <div className="space-y-4">
      <h1 className="text-lg font-bold text-gray-900">달리기 기록 제출</h1>

      <RunnerSelect
        runners={runners}
        value={runnerId}
        onChange={v => { setRunnerId(v); if (step === 'select') setStep('upload') }}
      />

      {runnerId && step !== 'select' && (
        <ImageUpload onFile={handleImage} preview={imagePreview} />
      )}

      {step === 'extracting' && (
        <div className="text-center text-sm text-gray-500 animate-pulse py-4">
          AI가 기록을 분석 중입니다...
        </div>
      )}

      {step === 'manual' && (
        <ManualForm onSubmit={handleManual} />
      )}

      {step === 'review' && extracted && (
        <>
          {speedWarning && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3 text-sm text-yellow-800">
              ⚠️ 기준 속도(7~10분/km)를 벗어났습니다. 제출은 가능하지만 스폰서가 거절할 수 있습니다.
            </div>
          )}
          <ExtractResult
            data={extracted}
            onConfirm={handleSubmit}
            onManual={() => setStep('manual')}
          />
        </>
      )}

      {step === 'submitting' && (
        <div className="text-center text-sm text-gray-500 py-4">제출 중...</div>
      )}

      {error && <p className="text-red-500 text-sm text-center">{error}</p>}
    </div>
  )
}
