import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'
import Link from 'next/link'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: '일달천금',
  description: '천원길도 1킬로부터',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ko">
      <body className={`${inter.className} bg-gray-50 min-h-screen`}>
        <header className="bg-white border-b border-gray-200 sticky top-0 z-10">
          <div className="max-w-lg mx-auto px-4 py-3 flex items-center justify-between">
            <Link href="/" className="font-bold text-lg text-gray-900">🏃 일달천금</Link>
            <Link
              href="/submit"
              className="bg-green-500 text-white text-sm px-4 py-1.5 rounded-full font-medium hover:bg-green-600 transition-colors"
            >
              기록 제출
            </Link>
          </div>
        </header>
        <main className="max-w-lg mx-auto px-4 py-6 space-y-4">
          {children}
        </main>
      </body>
    </html>
  )
}
