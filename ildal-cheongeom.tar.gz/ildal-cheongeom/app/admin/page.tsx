'use client'
import { useState, useEffect, useCallback } from 'react'
import { Runner, Submission, SafeConfig } from '@/types'
import { AdminLogin } from '@/components/admin/AdminLogin'
import { AddRunnerForm } from '@/components/admin/AddRunnerForm'
import { SubmissionCard } from '@/components/admin/SubmissionCard'
import { RunnerBadge } from '@/components/RunnerBadge'
import { BudgetBar } from '@/components/BudgetBar'

export default function AdminPage() {
  const [authed, setAuthed] = useState<boolean | null>(null)
  const [runners, setRunners] = useState<Runner[]>([])
  const [selectedRunner, setSelectedRunner] = useState<Runner | null>(null)
  const [submissions, setSubmissions] = useState<Submission[]>([])
  const [config, setConfig] = useState<SafeConfig | null>(null)
  const [showAddForm, setShowAddForm] = useState(false)

  // 마운트 시 기존 세션 확인
  useEffect(() => {
    fetch('/api/config')
      .then(res => { setAuthed(res.ok); return res.ok ? res.json() : null })
      .then(data => { if (data) setConfig(data) })
      .catch(() => setAuthed(false))
  }, [])

  const loadRunners = useCallback(async () => {
    const res = await fetch('/api/runners')
    setRunners(await res.json())
  }, [])

  const loadConfig = useCallback(async () => {
    const res = await fetch('/api/config')
    if (res.ok) setConfig(await res.json())
  }, [])

  const loadSubmissions = useCallback(async (runnerId: string) => {
    const res = await fetch(`/api/submissions?runnerId=${runnerId}`)
    setSubmissions(await res.json())
  }, [])

  useEffect(() => {
    if (authed) { loadRunners(); if (!config) loadConfig() }
  }, [authed, loadRunners, loadConfig, config])

  useEffect(() => {
    if (selectedRunner) loadSubmissions(selectedRunner.id)
  }, [selectedRunner, loadSubmissions])

  const handleApprove = async (submissionId: string) => {
    await fetch('/api/admin/submissions/approve', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ submissionId }),
    })
    if (selectedRunner) loadSubmissions(selectedRunner.id)
    loadRunners(); loadConfig()
  }

  const handleReject = async (submissionId: string, memo: string) => {
    await fetch('/api/admin/submissions/reject', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ submissionId, memo }),
    })
    if (selectedRunner) loadSubmissions(selectedRunner.id)
    loadRunners()
  }

  if (authed === null) return <div className="text-center py-8 text-gray-400">로딩 중...</div>
  if (!authed) return <AdminLogin onLogin={() => { setAuthed(true); loadRunners(); loadConfig() }} />

  const pendingSubmissions = submissions.filter(s => s.status === 'pending')
  const otherSubmissions = submissions.filter(s => s.status !== 'pending')
  const isOverBudget = config && config.spentAmount >= config.totalBudget

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-lg font-bold">관리자</h1>
        <button onClick={() => setShowAddForm(v => !v)} className="text-sm text-green-600 font-medium">
          {showAddForm ? '접기' : '+ 러너 추가'}
        </button>
      </div>

      {config && <BudgetBar total={config.totalBudget} spent={config.spentAmount} />}
      {isOverBudget && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-3 text-sm text-red-700">
          ⚠️ 예산이 소진되었습니다. 기존 대기 기록 승인은 가능하나 초과됩니다.
        </div>
      )}

      {showAddForm && (
        <AddRunnerForm onAdded={() => { loadRunners(); setShowAddForm(false) }} />
      )}

      <div>
        <p className="text-sm font-semibold text-gray-700 mb-2">러너 명단</p>
        <div className="grid grid-cols-2 gap-2">
          {runners.map(r => (
            <button
              key={r.id}
              onClick={() => setSelectedRunner(r)}
              className={`p-3 rounded-xl text-left border transition-colors ${
                selectedRunner?.id === r.id
                  ? 'border-green-400 bg-green-50'
                  : 'border-gray-200 bg-white hover:border-gray-300'
              }`}
            >
              <div className="flex items-center gap-1 mb-1">
                <span className="font-medium text-sm">{r.name}</span>
                <RunnerBadge group={r.group} />
              </div>
              {r.pendingAmount > 0 && (
                <span className="text-xs text-yellow-600">대기 {r.pendingAmount.toLocaleString()}원</span>
              )}
            </button>
          ))}
          {runners.length === 0 && (
            <p className="text-gray-400 text-sm col-span-2 py-2">러너가 없습니다. 먼저 추가하세요.</p>
          )}
        </div>
      </div>

      {selectedRunner && (
        <div className="space-y-3">
          <p className="text-sm font-semibold text-gray-700">{selectedRunner.name}의 기록</p>
          {pendingSubmissions.length === 0 && otherSubmissions.length === 0 && (
            <p className="text-gray-400 text-sm text-center py-4">기록이 없습니다</p>
          )}
          {pendingSubmissions.map(sub => (
            <SubmissionCard
              key={sub.id}
              submission={sub}
              tossId={selectedRunner.tossId}
              onApprove={() => handleApprove(sub.id)}
              onReject={(memo) => handleReject(sub.id, memo)}
              speedMin={config?.speedMinMinPerKm ?? 7}
              speedMax={config?.speedMaxMinPerKm ?? 10}
            />
          ))}
          {otherSubmissions.map(sub => (
            <SubmissionCard
              key={sub.id}
              submission={sub}
              tossId={selectedRunner.tossId}
              onApprove={() => handleApprove(sub.id)}
              onReject={(memo) => handleReject(sub.id, memo)}
              speedMin={config?.speedMinMinPerKm ?? 7}
              speedMax={config?.speedMaxMinPerKm ?? 10}
            />
          ))}
        </div>
      )}
    </div>
  )
}
