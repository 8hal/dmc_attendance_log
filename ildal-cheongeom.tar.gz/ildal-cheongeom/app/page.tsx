import { BudgetBar } from '@/components/BudgetBar'
import { Leaderboard } from '@/components/Leaderboard'
import { Runner, Config } from '@/types'
import { adminDb } from '@/lib/firebase-admin'

async function getData(): Promise<{ runners: Runner[]; config: Config }> {
  const [runnersSnap, configDoc] = await Promise.all([
    adminDb.collection('runners').get(),
    adminDb.doc('settings/main').get(),
  ])
  const runners = runnersSnap.docs.map(d => ({ id: d.id, ...d.data() } as Runner))
  const config = configDoc.data() as Config
  return { runners, config }
}

export default async function HomePage() {
  const { runners, config } = await getData()
  return (
    <>
      <BudgetBar total={config.totalBudget} spent={config.spentAmount} />
      <h2 className="text-base font-semibold text-gray-700">리더보드</h2>
      <Leaderboard runners={runners} />
    </>
  )
}
