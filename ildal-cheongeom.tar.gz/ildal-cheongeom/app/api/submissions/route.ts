import { NextRequest, NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'
import { FieldValue } from 'firebase-admin/firestore'
import { calcPace } from '@/lib/pace'

export async function GET(req: NextRequest) {
  const runnerId = req.nextUrl.searchParams.get('runnerId')
  let query = adminDb.collection('submissions').orderBy('submittedAt', 'desc')
  if (runnerId) {
    query = query.where('runnerId', '==', runnerId) as typeof query
  }
  const snapshot = await query.get()
  const submissions = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
  return NextResponse.json(submissions)
}

export async function POST(req: NextRequest) {
  let body: Record<string, unknown>
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 })
  }

  const { runnerId, runnerName, imageUrl, distanceKm, durationSec } = body

  if (!runnerId || !runnerName || typeof distanceKm !== 'number' || typeof durationSec !== 'number') {
    return NextResponse.json({ error: '필수 항목 누락' }, { status: 400 })
  }

  const submissionRef = adminDb.collection('submissions').doc()
  const runnerRef = adminDb.doc(`runners/${runnerId as string}`)
  const configRef = adminDb.doc('settings/main')

  try {
    let amount = 0
    await adminDb.runTransaction(async (tx) => {
      const configSnap = await tx.get(configRef)
      if (!configSnap.exists) throw new Error('CONFIG_NOT_FOUND')
      const config = configSnap.data()!

      if (config.spentAmount >= config.totalBudget) throw new Error('BUDGET_EXCEEDED')

      const ratePerKm = config.ratePerKm as number
      const paceMinPerKm = calcPace(distanceKm, durationSec)
      amount = Math.floor(distanceKm) * ratePerKm

      tx.set(submissionRef, {
        runnerId, runnerName,
        imageUrl: imageUrl ?? null,
        distanceKm, durationSec, paceMinPerKm, amount,
        status: 'pending',
        submittedAt: new Date().toISOString(),
        approvedAt: null,
      })
      tx.update(runnerRef, { pendingAmount: FieldValue.increment(amount) })
    })
    return NextResponse.json({ id: submissionRef.id, amount })
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : ''
    if (msg === 'BUDGET_EXCEEDED') return NextResponse.json({ error: '자본금이 소진되었습니다.' }, { status: 400 })
    if (msg === 'CONFIG_NOT_FOUND') return NextResponse.json({ error: '설정 없음' }, { status: 500 })
    return NextResponse.json({ error: '서버 오류' }, { status: 500 })
  }
}
