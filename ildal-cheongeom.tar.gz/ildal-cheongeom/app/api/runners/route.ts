import { NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'

export async function GET() {
  const snapshot = await adminDb.collection('runners').orderBy('name').get()
  const runners = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
  return NextResponse.json(runners)
}
