import { NextRequest, NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'
import { requireAdmin } from '@/lib/auth'

export async function GET(req: NextRequest) {
  if (!(await requireAdmin())) return NextResponse.json({ error: '권한 없음' }, { status: 401 })
  const doc = await adminDb.doc('settings/main').get()
  if (!doc.exists) return NextResponse.json({ error: '설정 없음' }, { status: 500 })
  const data = doc.data()!
  const { adminPassword: _pw, ...safeConfig } = data
  return NextResponse.json(safeConfig)
}
