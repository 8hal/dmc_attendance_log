import { NextRequest, NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'
import { signAdminToken, COOKIE_NAME } from '@/lib/auth'
import bcrypt from 'bcryptjs'

export async function POST(req: NextRequest) {
  let body: { password?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 })
  }
  const { password } = body
  if (!password) return NextResponse.json({ error: '비밀번호를 입력하세요.' }, { status: 400 })

  const configDoc = await adminDb.doc('settings/main').get()
  if (!configDoc.exists) return NextResponse.json({ error: '설정 없음' }, { status: 500 })

  const data = configDoc.data()!
  const { adminPassword } = data
  if (!adminPassword) return NextResponse.json({ error: '서버 설정 오류' }, { status: 500 })
  const match = await bcrypt.compare(password, adminPassword)
  if (!match) return NextResponse.json({ error: '비밀번호가 틀렸습니다.' }, { status: 401 })

  const token = await signAdminToken(process.env.JWT_SECRET!)
  const res = NextResponse.json({ ok: true })
  res.cookies.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 7,
    path: '/',
  })
  return res
}
