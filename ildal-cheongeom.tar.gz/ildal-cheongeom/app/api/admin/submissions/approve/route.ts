import { NextRequest, NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'
import { requireAdmin } from '@/lib/auth'
import { FieldValue } from 'firebase-admin/firestore'

export async function POST(req: NextRequest) {
  if (!(await requireAdmin())) return NextResponse.json({ error: '권한 없음' }, { status: 401 })

  let body: { submissionId?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 })
  }

  const { submissionId } = body
  if (!submissionId) return NextResponse.json({ error: 'submissionId 필요' }, { status: 400 })

  const subRef = adminDb.doc(`submissions/${submissionId}`)

  try {
    let amount = 0
    await adminDb.runTransaction(async (tx) => {
      const subSnap = await tx.get(subRef)
      if (!subSnap.exists) throw new Error('NOT_FOUND')
      const sub = subSnap.data()!
      if (sub.status !== 'pending') throw new Error('NOT_PENDING')

      amount = sub.amount
      const runnerRef = adminDb.doc(`runners/${sub.runnerId}`)
      const configRef = adminDb.doc('settings/main')

      tx.update(subRef, { status: 'approved', approvedAt: new Date().toISOString() })
      tx.update(runnerRef, {
        totalKm: FieldValue.increment(sub.distanceKm),
        totalAmount: FieldValue.increment(sub.amount),
        pendingAmount: FieldValue.increment(-sub.amount),
      })
      tx.update(configRef, { spentAmount: FieldValue.increment(sub.amount) })
    })
    return NextResponse.json({ ok: true, amount })
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : ''
    if (msg === 'NOT_FOUND') return NextResponse.json({ error: '기록 없음' }, { status: 404 })
    if (msg === 'NOT_PENDING') return NextResponse.json({ error: '대기 상태가 아님' }, { status: 400 })
    return NextResponse.json({ error: '서버 오류' }, { status: 500 })
  }
}
