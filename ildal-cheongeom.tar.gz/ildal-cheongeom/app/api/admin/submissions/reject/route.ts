import { NextRequest, NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'
import { requireAdmin } from '@/lib/auth'
import { FieldValue } from 'firebase-admin/firestore'

export async function POST(req: NextRequest) {
  if (!(await requireAdmin())) return NextResponse.json({ error: '권한 없음' }, { status: 401 })

  let body: { submissionId?: string; memo?: string }
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 })
  }

  const { submissionId, memo } = body
  if (!submissionId) return NextResponse.json({ error: 'submissionId 필요' }, { status: 400 })

  const subRef = adminDb.doc(`submissions/${submissionId}`)

  try {
    await adminDb.runTransaction(async (tx) => {
      const subSnap = await tx.get(subRef)
      if (!subSnap.exists) throw new Error('NOT_FOUND')
      const sub = subSnap.data()!
      if (sub.status !== 'pending') throw new Error('NOT_PENDING')

      const runnerRef = adminDb.doc(`runners/${sub.runnerId}`)
      tx.update(subRef, { status: 'rejected', memo: memo || '' })
      tx.update(runnerRef, { pendingAmount: FieldValue.increment(-sub.amount) })
    })
    return NextResponse.json({ ok: true })
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : ''
    if (msg === 'NOT_FOUND') return NextResponse.json({ error: '기록 없음' }, { status: 404 })
    if (msg === 'NOT_PENDING') return NextResponse.json({ error: '대기 상태가 아님' }, { status: 400 })
    return NextResponse.json({ error: '서버 오류' }, { status: 500 })
  }
}
