import { NextRequest, NextResponse } from 'next/server'
import { adminDb } from '@/lib/firebase-admin'
import { requireAdmin } from '@/lib/auth'

export async function POST(req: NextRequest) {
  if (!(await requireAdmin())) {
    return NextResponse.json({ error: '권한 없음' }, { status: 401 })
  }
  let body: Record<string, unknown>
  try {
    body = await req.json()
  } catch {
    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 })
  }
  const { name, group, tossId } = body
  if (!name || !group) return NextResponse.json({ error: '이름과 그룹은 필수입니다.' }, { status: 400 })
  if (!['highschool', 'university'].includes(group as string)) {
    return NextResponse.json({ error: '그룹은 highschool 또는 university 이어야 합니다.' }, { status: 400 })
  }

  const ref = adminDb.collection('runners').doc()
  await ref.set({
    name,
    group,
    tossId: tossId || '',
    totalKm: 0,
    totalAmount: 0,
    pendingAmount: 0,
  })
  return NextResponse.json({ id: ref.id })
}
