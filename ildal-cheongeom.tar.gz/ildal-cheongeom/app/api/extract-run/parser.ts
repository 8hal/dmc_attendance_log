import { ExtractedRun } from '@/types'

export function parseExtractedJson(raw: string): ExtractedRun | null {
  try {
    const data = JSON.parse(raw)
    if (
      typeof data.distanceKm !== 'number' ||
      typeof data.durationSec !== 'number' ||
      typeof data.paceMinPerKm !== 'number'
    ) return null
    return data as ExtractedRun
  } catch {
    return null
  }
}
