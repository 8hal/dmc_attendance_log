import { NextRequest, NextResponse } from 'next/server'
import OpenAI from 'openai'
import { adminStorage } from '@/lib/firebase-admin'
import { parseExtractedJson } from './parser'
import { v4 as uuidv4 } from 'uuid'

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY })

const EXTRACT_PROMPT = `이 이미지는 러닝 앱(Strava, Nike Run Club, 삼성 헬스 등)의 운동 기록 화면입니다.
다음 정보를 JSON으로만 반환하세요. 다른 텍스트 없이 JSON만 출력하세요.
{
  "distanceKm": <숫자, km 단위>,
  "durationSec": <숫자, 초 단위>,
  "paceMinPerKm": <숫자, 분/km 단위>
}
정보를 확인할 수 없으면 해당 필드에 null을 넣으세요.`

export async function POST(req: NextRequest) {
  let file: File | null = null
  try {
    const formData = await req.formData()
    file = formData.get('image') as File | null
  } catch {
    return NextResponse.json({ error: '잘못된 요청입니다.' }, { status: 400 })
  }

  if (!file) return NextResponse.json({ error: '이미지가 없습니다.' }, { status: 400 })
  if (!(file instanceof Blob)) {
    return NextResponse.json({ error: '이미지 파일을 첨부해주세요.' }, { status: 400 })
  }

  const buffer = Buffer.from(await file.arrayBuffer())
  const base64 = buffer.toString('base64')
  const mimeType = file.type || 'image/jpeg'

  let extracted = null
  try {
    const response = await openai.chat.completions.create({
      model: 'gpt-4o',
      max_tokens: 200,
      messages: [{
        role: 'user',
        content: [
          { type: 'text', text: EXTRACT_PROMPT },
          { type: 'image_url', image_url: { url: `data:${mimeType};base64,${base64}` } },
        ],
      }],
    })
    const content = response.choices[0].message.content ?? ''
    extracted = parseExtractedJson(content)
  } catch {
    // 추출 실패 → extracted = null (fallback 안내)
  }

  let imageUrl: string
  try {
    const ext = file.name?.split('.').pop() || 'jpg'
    const filename = `submissions/${uuidv4()}.${ext}`
    const bucket = adminStorage.bucket()
    const fileRef = bucket.file(filename)
    await fileRef.save(buffer, { contentType: mimeType })
    await fileRef.makePublic()
    imageUrl = `https://storage.googleapis.com/${bucket.name}/${filename}`
  } catch {
    return NextResponse.json({ error: '이미지 저장에 실패했습니다.' }, { status: 500 })
  }

  return NextResponse.json({ extracted, imageUrl })
}
