import { SignJWT, jwtVerify } from 'jose'

export const COOKIE_NAME = 'admin_token'
const TOKEN_TTL = '7d'

export async function signAdminToken(secret: string): Promise<string> {
  if (!secret) throw new Error('JWT_SECRET is not configured')
  const key = new TextEncoder().encode(secret)
  return new SignJWT({ role: 'admin' })
    .setProtectedHeader({ alg: 'HS256' })
    .setExpirationTime(TOKEN_TTL)
    .sign(key)
}

export async function verifyAdminToken(token: string, secret: string): Promise<boolean> {
  if (!secret) throw new Error('JWT_SECRET is not configured')
  try {
    const key = new TextEncoder().encode(secret)
    await jwtVerify(token, key)
    return true
  } catch {
    return false
  }
}

export async function requireAdmin(): Promise<boolean> {
  const { cookies } = await import('next/headers')
  const cookieStore = await cookies()
  const token = cookieStore.get(COOKIE_NAME)?.value
  if (!token) return false
  return verifyAdminToken(token, process.env.JWT_SECRET!)
}
