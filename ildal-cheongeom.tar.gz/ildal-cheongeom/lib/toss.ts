export function makeTossLink(tossId: string | undefined, amount: number): string | null {
  if (!tossId) return null
  return `https://toss.me/${tossId}/${amount}`
}
