import { calcPace, formatDuration, formatPace, isSpeedValid } from '../pace'

describe('calcPace', () => {
  it('5km 30분 → 6.0 분/km', () => {
    expect(calcPace(5, 1800)).toBe(6.0)
  })
  it('1km 480초 → 8.0 분/km', () => {
    expect(calcPace(1, 480)).toBe(8.0)
  })
})

describe('formatDuration', () => {
  it('480초 → "8:00"', () => {
    expect(formatDuration(480)).toBe('8:00')
  })
  it('3661초 → "1:01:01"', () => {
    expect(formatDuration(3661)).toBe('1:01:01')
  })
})

describe('formatPace', () => {
  it('6.5 → "6\'30\""', () => {
    expect(formatPace(6.5)).toBe("6'30\"")
  })
})

describe('isSpeedValid', () => {
  it('8분/km → true (기준 7~10)', () => {
    expect(isSpeedValid(8, 7, 10)).toBe(true)
  })
  it('6분/km → false (너무 빠름)', () => {
    expect(isSpeedValid(6, 7, 10)).toBe(false)
  })
  it('11분/km → false (너무 느림)', () => {
    expect(isSpeedValid(11, 7, 10)).toBe(false)
  })
})
