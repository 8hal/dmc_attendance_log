import { parseExtractedJson } from '../../app/api/extract-run/parser'

describe('parseExtractedJson', () => {
  it('정상 JSON 파싱', () => {
    const input = JSON.stringify({ distanceKm: 5.2, durationSec: 2400, paceMinPerKm: 7.7 })
    const result = parseExtractedJson(input)
    expect(result).toEqual({ distanceKm: 5.2, durationSec: 2400, paceMinPerKm: 7.7 })
  })

  it('필수 필드 누락 시 null 반환', () => {
    const input = JSON.stringify({ distanceKm: 5.2 })
    expect(parseExtractedJson(input)).toBeNull()
  })

  it('잘못된 JSON은 null 반환', () => {
    expect(parseExtractedJson('not json')).toBeNull()
  })

  it('필드가 숫자가 아니면 null 반환', () => {
    const input = JSON.stringify({ distanceKm: '5.2', durationSec: 2400, paceMinPerKm: 7.7 })
    expect(parseExtractedJson(input)).toBeNull()
  })
})
