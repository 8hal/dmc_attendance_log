// @vitest-environment node
import { signAdminToken, verifyAdminToken } from '../auth'

describe('JWT 쿠키 서명 및 검증', () => {
  const secret = 'test-secret-key-32-chars-minimum!!'

  it('서명된 토큰을 검증할 수 있다', async () => {
    const token = await signAdminToken(secret)
    const result = await verifyAdminToken(token, secret)
    expect(result).toBe(true)
  })

  it('잘못된 토큰은 false 반환', async () => {
    const result = await verifyAdminToken('invalid.token.here', secret)
    expect(result).toBe(false)
  })

  it('다른 시크릿으로 서명한 토큰은 검증 실패', async () => {
    const token = await signAdminToken('other-secret-key-32-chars-minimum!')
    const result = await verifyAdminToken(token, secret)
    expect(result).toBe(false)
  })
})
