import { makeTossLink } from '../toss'

describe('makeTossLink', () => {
  it('tossId와 금액으로 링크 생성', () => {
    expect(makeTossLink('runner1', 5000)).toBe('https://toss.me/runner1/5000')
  })
  it('tossId 없으면 null 반환', () => {
    expect(makeTossLink('', 5000)).toBeNull()
    expect(makeTossLink(undefined, 5000)).toBeNull()
  })
})
