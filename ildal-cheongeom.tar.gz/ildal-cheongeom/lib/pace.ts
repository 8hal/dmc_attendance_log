export function calcPace(distanceKm: number, durationSec: number): number {
  const paceMin = durationSec / 60 / distanceKm
  return Math.round(paceMin * 100) / 100
}

export function formatDuration(totalSec: number): string {
  const h = Math.floor(totalSec / 3600)
  const m = Math.floor((totalSec % 3600) / 60)
  const s = totalSec % 60
  if (h > 0) return `${h}:${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`
  return `${m}:${String(s).padStart(2, '0')}`
}

export function formatPace(paceMinPerKm: number): string {
  const min = Math.floor(paceMinPerKm)
  const sec = Math.round((paceMinPerKm - min) * 60)
  return `${min}'${String(sec).padStart(2, '0')}"`
}

export function isSpeedValid(
  paceMinPerKm: number,
  minPace: number,
  maxPace: number
): boolean {
  return paceMinPerKm >= minPace && paceMinPerKm <= maxPace
}
