export function BudgetBar({ total, spent }: { total: number; spent: number }) {
  const remaining = total - spent
  const pct = Math.min(100, (spent / total) * 100)
  const isOver = spent >= total

  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm">
      <div className="flex justify-between items-center mb-2">
        <span className="text-sm font-medium text-gray-600">자본금 잔액</span>
        <span className={`text-lg font-bold ${isOver ? 'text-red-500' : 'text-green-600'}`}>
          {remaining.toLocaleString()}원
        </span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div
          className={`h-2 rounded-full transition-all ${isOver ? 'bg-red-400' : 'bg-green-400'}`}
          style={{ width: `${pct}%` }}
        />
      </div>
      <div className="flex justify-between text-xs text-gray-400 mt-1">
        <span>지급: {spent.toLocaleString()}원</span>
        <span>총: {total.toLocaleString()}원</span>
      </div>
      {isOver && (
        <p className="text-xs text-red-500 mt-1 font-medium">⚠️ 자본금이 소진되었습니다. 새 제출이 차단됩니다.</p>
      )}
    </div>
  )
}
