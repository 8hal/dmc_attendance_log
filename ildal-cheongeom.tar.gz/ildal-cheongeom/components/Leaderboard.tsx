import { Runner } from '@/types'
import { RunnerBadge } from './RunnerBadge'
import Link from 'next/link'

export function Leaderboard({ runners }: { runners: Runner[] }) {
  const sorted = [...runners].sort((a, b) => b.totalAmount - a.totalAmount)
  return (
    <div className="bg-white rounded-2xl shadow-sm overflow-hidden">
      <table className="w-full">
        <thead className="bg-gray-50 text-xs text-gray-500 uppercase">
          <tr>
            <th className="px-4 py-3 text-left">순위</th>
            <th className="px-4 py-3 text-left">러너</th>
            <th className="px-4 py-3 text-right">km</th>
            <th className="px-4 py-3 text-right">획득 금액</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-gray-100">
          {sorted.map((runner, i) => (
            <tr key={runner.id} className="hover:bg-gray-50 transition-colors">
              <td className="px-4 py-3 text-sm font-bold text-gray-500">{i + 1}</td>
              <td className="px-4 py-3">
                <Link href={`/records/${runner.id}`} className="flex items-center gap-2">
                  <span className="font-medium text-gray-900">{runner.name}</span>
                  <RunnerBadge group={runner.group} />
                </Link>
              </td>
              <td className="px-4 py-3 text-right text-sm text-gray-600">
                {runner.totalKm.toFixed(1)} km
              </td>
              <td className="px-4 py-3 text-right font-semibold text-green-600">
                {runner.totalAmount.toLocaleString()}원
              </td>
            </tr>
          ))}
          {sorted.length === 0 && (
            <tr>
              <td colSpan={4} className="px-4 py-8 text-center text-gray-400">
                아직 기록이 없습니다
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  )
}
