import { RunnerGroup } from '@/types'

const GROUP_LABELS: Record<RunnerGroup, string> = {
  highschool: '고등',
  university: '대학',
}
const GROUP_COLORS: Record<RunnerGroup, string> = {
  highschool: 'bg-blue-100 text-blue-700',
  university: 'bg-purple-100 text-purple-700',
}

export function RunnerBadge({ group }: { group: RunnerGroup }) {
  return (
    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${GROUP_COLORS[group]}`}>
      {GROUP_LABELS[group]}
    </span>
  )
}
