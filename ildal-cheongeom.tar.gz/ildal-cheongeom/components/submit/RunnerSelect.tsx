'use client'
import { Runner } from '@/types'

export function RunnerSelect({
  runners, value, onChange
}: { runners: Runner[]; value: string; onChange: (id: string) => void }) {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">내 이름 선택</label>
      <select
        value={value}
        onChange={e => onChange(e.target.value)}
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-green-400"
      >
        <option value="">-- 선택하세요 --</option>
        {runners.map(r => (
          <option key={r.id} value={r.id}>{r.name}</option>
        ))}
      </select>
    </div>
  )
}
