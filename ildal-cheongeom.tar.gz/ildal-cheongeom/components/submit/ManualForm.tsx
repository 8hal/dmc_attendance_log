'use client'
import { useState } from 'react'
import { calcPace } from '@/lib/pace'
import { ExtractedRun } from '@/types'

export function ManualForm({ onSubmit }: { onSubmit: (data: ExtractedRun) => void }) {
  const [distanceKm, setDistanceKm] = useState('')
  const [minutes, setMinutes] = useState('')
  const [seconds, setSeconds] = useState('')

  const handleSubmit = () => {
    const dist = parseFloat(distanceKm)
    const min = parseInt(minutes || '0')
    const sec = parseInt(seconds || '0')
    if (!dist || (!min && !sec)) return
    const durationSec = min * 60 + sec
    const paceMinPerKm = calcPace(dist, durationSec)
    onSubmit({ distanceKm: dist, durationSec, paceMinPerKm })
  }

  return (
    <div className="space-y-3">
      <p className="text-sm font-medium text-gray-700">직접 입력</p>
      <div>
        <label className="text-xs text-gray-500">거리 (km) *</label>
        <input
          type="number" step="0.01" value={distanceKm}
          onChange={e => setDistanceKm(e.target.value)}
          className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm mt-1"
          placeholder="5.0"
        />
      </div>
      <div className="flex gap-2">
        <div className="flex-1">
          <label className="text-xs text-gray-500">분 *</label>
          <input
            type="number" value={minutes} onChange={e => setMinutes(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm mt-1"
            placeholder="30"
          />
        </div>
        <div className="flex-1">
          <label className="text-xs text-gray-500">초 *</label>
          <input
            type="number" value={seconds} onChange={e => setSeconds(e.target.value)}
            className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm mt-1"
            placeholder="0"
          />
        </div>
      </div>
      <button
        onClick={handleSubmit}
        className="w-full bg-gray-700 text-white py-2 rounded-lg text-sm font-medium"
      >
        입력 완료
      </button>
    </div>
  )
}
