'use client'
import { ExtractedRun } from '@/types'
import { formatDuration, formatPace } from '@/lib/pace'

export function ExtractResult({
  data, onConfirm, onManual
}: {
  data: ExtractedRun
  onConfirm: () => void
  onManual: () => void
}) {
  return (
    <div className="bg-green-50 border border-green-200 rounded-xl p-4 space-y-3">
      <p className="text-sm font-semibold text-green-800">✅ AI 추출 결과</p>
      <div className="grid grid-cols-3 gap-2 text-center">
        <div className="bg-white rounded-lg p-2">
          <p className="text-xs text-gray-500">거리</p>
          <p className="font-bold text-gray-900">{data.distanceKm.toFixed(2)} km</p>
        </div>
        <div className="bg-white rounded-lg p-2">
          <p className="text-xs text-gray-500">시간</p>
          <p className="font-bold text-gray-900">{formatDuration(data.durationSec)}</p>
        </div>
        <div className="bg-white rounded-lg p-2">
          <p className="text-xs text-gray-500">페이스</p>
          <p className="font-bold text-gray-900">{formatPace(data.paceMinPerKm)}/km</p>
        </div>
      </div>
      <div className="flex gap-2">
        <button onClick={onConfirm} className="flex-1 bg-green-500 text-white py-2 rounded-lg text-sm font-medium">
          이대로 제출
        </button>
        <button onClick={onManual} className="flex-1 border border-gray-300 text-gray-600 py-2 rounded-lg text-sm">
          직접 수정
        </button>
      </div>
    </div>
  )
}
