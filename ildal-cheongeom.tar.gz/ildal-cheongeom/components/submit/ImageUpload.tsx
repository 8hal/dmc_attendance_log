'use client'
import { useRef } from 'react'

export function ImageUpload({
  onFile, preview
}: { onFile: (file: File) => void; preview: string | null }) {
  const inputRef = useRef<HTMLInputElement>(null)
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700 mb-1">러닝 기록 스크린샷</label>
      <button
        type="button"
        onClick={() => inputRef.current?.click()}
        className="w-full border-2 border-dashed border-gray-300 rounded-xl p-6 text-center text-gray-500 text-sm hover:border-green-400 transition-colors"
      >
        {preview ? (
          <img src={preview} alt="업로드 이미지" className="max-h-48 mx-auto rounded-lg" />
        ) : (
          <span>📸 탭하여 사진 선택</span>
        )}
      </button>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={e => { const f = e.target.files?.[0]; if (f) onFile(f) }}
      />
    </div>
  )
}
