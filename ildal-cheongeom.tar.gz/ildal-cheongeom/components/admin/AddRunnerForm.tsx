'use client'
import { useState } from 'react'

export function AddRunnerForm({ onAdded }: { onAdded: () => void }) {
  const [name, setName] = useState('')
  const [group, setGroup] = useState<'highschool' | 'university'>('highschool')
  const [tossId, setTossId] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!name) return
    setLoading(true)
    await fetch('/api/admin/runners', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ name, group, tossId }),
    })
    setName(''); setTossId(''); setLoading(false)
    onAdded()
  }

  return (
    <form onSubmit={handleSubmit} className="bg-gray-50 rounded-xl p-4 space-y-3">
      <p className="text-sm font-semibold text-gray-700">러너 추가</p>
      <input value={name} onChange={e => setName(e.target.value)} placeholder="이름 *"
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" />
      <select value={group} onChange={e => setGroup(e.target.value as typeof group)}
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm">
        <option value="highschool">고등학교 친구</option>
        <option value="university">대학교 친구</option>
      </select>
      <input value={tossId} onChange={e => setTossId(e.target.value)} placeholder="토스 아이디 (선택)"
        className="w-full border border-gray-300 rounded-lg px-3 py-2 text-sm" />
      <button type="submit" disabled={loading}
        className="w-full bg-green-500 text-white py-2 rounded-lg text-sm font-medium disabled:opacity-50">
        {loading ? '추가 중...' : '추가'}
      </button>
    </form>
  )
}
