'use client'
import { Submission } from '@/types'
import { formatDuration, formatPace, isSpeedValid } from '@/lib/pace'
import { makeTossLink } from '@/lib/toss'

export function SubmissionCard({
  submission, tossId, onApprove, onReject, speedMin, speedMax
}: {
  submission: Submission
  tossId?: string
  onApprove: () => void
  onReject: (memo: string) => void
  speedMin: number
  speedMax: number
}) {
  const outOfRange = !isSpeedValid(submission.paceMinPerKm, speedMin, speedMax)
  const tossLink = makeTossLink(tossId, submission.amount)

  const handleReject = () => {
    const memo = window.prompt('거절 사유 (선택):') ?? ''
    onReject(memo)
  }

  return (
    <div className="bg-white rounded-xl p-4 shadow-sm space-y-3">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500">
          {new Date(submission.submittedAt).toLocaleString('ko-KR')}
        </span>
        {outOfRange && (
          <span className="text-xs bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded-full">
            ⚠️ 속도 기준 외
          </span>
        )}
      </div>
      <div className="flex gap-4 text-sm font-medium">
        <span>{submission.distanceKm.toFixed(2)} km</span>
        <span className="text-gray-500">{formatDuration(submission.durationSec)}</span>
        <span className="text-gray-500">{formatPace(submission.paceMinPerKm)}/km</span>
        <span className="text-green-600 ml-auto font-bold">{submission.amount.toLocaleString()}원</span>
      </div>
      {submission.imageUrl && (
        <a href={submission.imageUrl} target="_blank" rel="noopener noreferrer"
          className="block text-xs text-blue-500 underline">인증 사진 보기</a>
      )}
      {submission.status === 'pending' && (
        <div className="flex gap-2">
          <button onClick={onApprove}
            className="flex-1 bg-green-500 text-white py-2 rounded-lg text-sm font-medium">
            승인
          </button>
          <button onClick={handleReject}
            className="flex-1 border border-red-300 text-red-500 py-2 rounded-lg text-sm">
            거절
          </button>
        </div>
      )}
      {submission.status === 'approved' && tossLink && (
        <a href={tossLink} target="_blank" rel="noopener noreferrer"
          className="block w-full text-center bg-blue-500 text-white py-2 rounded-lg text-sm font-medium">
          💸 토스로 {submission.amount.toLocaleString()}원 송금
        </a>
      )}
      {submission.status === 'approved' && !tossLink && (
        <p className="text-xs text-gray-400 text-center">토스 아이디 미등록 — 직접 송금하세요</p>
      )}
      {submission.status === 'rejected' && (
        <p className="text-xs text-gray-400">거절됨 {submission.memo ? `— ${submission.memo}` : ''}</p>
      )}
    </div>
  )
}
